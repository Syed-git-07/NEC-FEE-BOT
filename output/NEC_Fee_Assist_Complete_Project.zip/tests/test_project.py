import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from app import service as s, nlp
from app.server import Handler

class ProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(); cls.old=s.DB;s.DB=Path(cls.temp.name)/'test.sqlite3';s.init()
        creds=json.loads((s.DB.parent/'demo_credentials.json').read_text())
        cls.student_result,cls.student_token=s.login(creds['student']['id'],creds['student']['password'])
        cls.admin_result,cls.admin_token=s.login('admin',creds['admin']['password'])
        cls.student=s.session(cls.student_token); cls.admin=s.session(cls.admin_token)
        s.add_student(cls.admin,{'id':'OTHER','name':'Other Student','department':'CSE','semester':7,'password':'Other-account-password'})
        _,cls.other_token=s.login('OTHER','Other-account-password');cls.other=s.session(cls.other_token)
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();s.DB=cls.old;cls.temp.cleanup()
    def setUp(self):
        with s.db() as c:
            for table in ['settlements','payment_items','payments','chat_messages']:c.execute('DELETE FROM '+table)
            c.execute("UPDATE fees SET status='pending'")
            c.execute("UPDATE sessions SET context=''")
        self.ids=[f['id'] for f in s.dashboard(self.student)['fees']]
    def attempt(self,ids=None,outcome='completed',key='test-payment-key-1234',user=None):
        return s.pay(user or self.student,{'fee_ids':ids or [self.ids[0]],'outcome':outcome,'idempotency_key':key})
    def error(self,code,fn):
        with self.assertRaises(s.Error) as cm:fn()
        self.assertEqual(cm.exception.status,code)
    def http(self,method,path,data=None,token=None,csrf=None,extra=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.server.server_address[1]);headers={}
        if token:headers['Cookie']='fee_session='+token
        if csrf:headers['X-CSRF-Token']=csrf
        body=json.dumps(data) if data is not None else None
        if body:headers['Content-Type']='application/json'
        headers.update(extra or {});conn.request(method,path,body,headers);r=conn.getresponse();b=r.read();result=(r.status,b,dict(r.getheaders()));conn.close();return result
    def test_success_settles_full_fee(self):
        p=self.attempt();f=s.dashboard(self.student)['fees'][0]
        self.assertEqual(f['status'],'paid');self.assertEqual(p['amount'],f['amount'])
    def test_failed_keeps_pending(self):
        self.attempt(outcome='failed');self.assertEqual(s.dashboard(self.student)['stats']['paid'],0)
    def test_cancelled_keeps_pending(self):
        self.attempt(outcome='cancelled');self.assertEqual(s.dashboard(self.student)['stats']['paid'],0)
    def test_idempotent_retry_same_receipt(self):
        self.assertEqual(self.attempt()['id'],self.attempt()['id'])
        self.assertEqual(len(s.dashboard(self.student)['payments']),1)
    def test_changed_replay_rejected(self):
        self.attempt();self.error(409,lambda:self.attempt(outcome='failed'))
    def test_second_payment_rejected(self):
        self.attempt();self.error(409,lambda:self.attempt(key='new-key-payment-1234'))
    def test_duplicate_fee_ids_rejected(self):self.error(400,lambda:self.attempt(ids=[self.ids[0]]*2))
    def test_foreign_fee_payment_rejected(self):self.error(404,lambda:self.attempt(user=self.other))
    def test_dashboard_owner_filter(self):self.assertEqual(s.dashboard(self.other)['fees'],[])
    def test_receipt_owner_filter(self):
        p=self.attempt();self.error(404,lambda:s.receipt(self.other,p['id']))
    def test_failed_receipt_unavailable(self):
        p=self.attempt(outcome='failed');self.error(409,lambda:s.receipt(self.student,p['id']))
    def test_receipt_pdf(self):
        p=self.attempt();self.assertTrue(s.receipt(self.student,p['id']).startswith(b'%PDF'))
    def test_student_cannot_assign_fee(self):self.error(403,lambda:s.add_fee(self.student,{}))
    def test_client_amount_rejected(self):
        self.error(400,lambda:s.pay(self.student,{'fee_ids':[self.ids[0]],'outcome':'completed','idempotency_key':'test-key-123456789','amount':1}))
    def test_missing_session(self):self.error(401,lambda:s.session('unknown'))
    def test_csrf_required(self):
        status,_,_=self.http('POST','/api/payment',{},self.student_token);self.assertEqual(status,403)
    def test_cross_origin_rejected(self):
        status,_,_=self.http('POST','/api/payment',{},self.student_token,self.student['csrf'],{'Origin':'https://attacker.example'});self.assertEqual(status,403)
    def test_invalid_host_rejected(self):
        status,_,_=self.http('GET','/',extra={'Host':'attacker.example'});self.assertEqual(status,403)
    def test_security_headers(self):
        status,_,headers=self.http('GET','/');self.assertEqual(status,200);self.assertEqual(headers['X-Frame-Options'],'DENY');self.assertIn("script-src 'self'",headers['Content-Security-Policy'])
    def test_admin_export_requires_role(self):
        status,_,_=self.http('GET','/api/admin/export',token=self.student_token);self.assertEqual(status,403)
    def test_http_receipt_and_csv(self):
        p=self.attempt();status,body,_=self.http('GET','/api/receipt/'+p['id'],token=self.student_token);self.assertEqual(status,200);self.assertTrue(body.startswith(b'%PDF'))
        status,body,_=self.http('GET','/api/admin/export',token=self.admin_token);self.assertEqual(status,200);self.assertIn(b'Fee head',body)
    def test_chat_live_balance_updates(self):
        before=s.chat(self.student,self.student_token,'What are my pending fees?')['answer'];self.attempt();after=s.chat(self.student,self.student_token,'What are my pending fees?')['answer'];self.assertNotEqual(before,after)
    def test_chat_context_due_date(self):
        s.chat(self.student,self.student_token,'How much is my tuition fee?');u=s.session(self.student_token)
        result=s.chat(u,self.student_token,'When?');self.assertIn('Tuition',result['answer']);self.assertNotIn('Examination',result['answer'])
    def test_chat_unknown_fallback(self):
        result=s.chat(self.student,self.student_token,'quantum banana nebula');self.assertEqual(result['intent'],'fallback')
    def test_chat_no_mutation(self):
        before=s.dashboard(self.student)['fees'];s.chat(self.student,self.student_token,'Pay all my fees now');self.assertEqual(before,s.dashboard(self.student)['fees'])
    def test_policy_update_available_in_chat(self):
        with s.db() as c:pid=c.execute("SELECT id FROM policies WHERE title='Refund requests'").fetchone()[0]
        s.update_policy(self.admin,{'id':pid,'title':'Refund requests','content':'Refund requests: contact the demonstration help desk. REFUNDTEST.'})
        result=s.chat(self.student,self.student_token,'refund requests');self.assertIn('REFUNDTEST',result['answer'])
        s.update_policy(self.admin,{'id':pid,'title':'Refund requests','content':s.POLICIES[2][1]})

if __name__=='__main__':unittest.main(verbosity=2)
