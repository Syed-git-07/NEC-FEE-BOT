# NEC Fee Assist

Independent academic fee portal and NLP chatbot for **SYED SUFYAN M - 2403957610421048**.

The project uses Python, SQLite and a browser interface. It runs locally and does not connect to the existing NEC fee portal, official ERP or a payment provider. Fees are illustrative; payments and receipts are demonstrations.

## Run on Windows

Open PowerShell in this project folder:

```powershell
.\run.ps1
```

If your PowerShell policy does not permit scripts, run the individual commands:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m app.server
```

Open **http://127.0.0.1:8765**. Stop the server with Ctrl+C. Another port can be selected with `--port 8766`.

On first start, random demonstration passwords are generated. Read them locally:

```powershell
Get-Content -LiteralPath .\data\demo_credentials.json
```

Student ID: `2403957610421048`. Administrator ID: `admin`. These accounts use different passwords. Do not distribute the credentials file or runtime database. New source-archive installations generate their own credentials.

## Features

- Student overview, pending fee selection, profile and transaction history.
- Completed, failed and cancelled simulated payments, with atomic settlement and idempotent retries.
- Owner-restricted PDF receipts for completed attempts.
- NLP fee assistant: balances, fee-specific deadlines, payment history, receipt links, profile and maintained policies.
- Administrator student creation, fee allotment, ledger search, CSV export, policy editing and audit history.
- Session cookies, salted PBKDF2 password hashes, role/ownership checks, CSRF, request bounds and rate limits.

The chatbot is offline rule-assisted TF-IDF retrieval, not a cloud LLM. It does not initiate payments, change account records or execute generated SQL. Similarity scores are retrieval scores, not calibrated confidence percentages.

## Delivered report

- `output/pdf/NEC_Fee_Portal_Project_Report_SYED_SUFYAN_M.pdf`: complete 52-page report.
- `output/NEC_Fee_Assist_Report_Editable.md`: editable report content.
- `scripts/report_content.py`: original structured report source.
- `output/screenshots/`: actual captured browser outputs.
- `output/diagrams/`: six original diagrams in PDF, SVG and PNG.
- `output/pdf/Sample_Demo_Payment_Receipt.pdf`: actual demonstration download.
- `output/sample_fee_ledger.csv`: administrator export captured during verification.

The reference report's college, degree, department, course and October 2026 submission details are retained. Its guide field is unsigned; no guide identity or signature is invented.

## Checks

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
node --check app/static/app.js
```

The backend suite has 26 tests using temporary databases. Browser evidence is in `output/browser_validation.json`.

To recreate screenshots, install the optional verification tools into your local virtual environment:

```powershell
.\.venv\Scripts\python.exe -m pip install playwright pymupdf
.\.venv\Scripts\python.exe -m playwright install chromium
.\.venv\Scripts\python.exe scripts/capture_outputs.py
.\.venv\Scripts\python.exe scripts/build_report.py
```

The server must be running on port 8765 for capture. **Capture creates payment attempts and a Project laboratory fee in this project's demonstration database.** It is intended for a fresh evaluation dataset and must not be used against a real fee system. Screenshots from an existing populated dataset will reflect its current values. Report generation alone does not modify database records.

## Limitations and deployment

The server binds only to loopback. The Python standard-library server is an evaluation server, not a production web service. Real deployment needs an authorized identity/data integration, a production server, HTTPS and Secure cookies, password lifecycle, approved financial policy and backup/retention procedures. Replace the simulation with server-created gateway orders and verified provider confirmations before accepting real payments. Bulk import, bank reconciliation, refunds, reminders, speech and multilingual support are future enhancements.

The source archive excludes `.venv`, runtime data, credentials, caches and reference PDFs. It includes the report assets so its PDF can be reproduced without the friends' reports. No Git commit, push or rebase was run.
